import {SeatMap} from '../models/seatMap';
const s=(id:string,a=true)=>({type:'SEAT' as const,seat:{id,label:id,available:a}});
const aisle={type:'AISLE' as const};
export const seatMap:SeatMap={decks:[{id:'MAIN',title:'Main Deck',sections:[{title:'Economy',rows:[
{row:30,elements:[s('30A'),s('30B',false),s('30C'),aisle,s('30D'),s('30E'),s('30F')]},
{row:31,elements:[s('31A'),s('31B'),s('31C'),aisle,s('31D',false),s('31E'),s('31F')]}
]}]}]};
