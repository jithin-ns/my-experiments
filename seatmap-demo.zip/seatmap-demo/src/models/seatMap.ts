export type ElementType='SEAT'|'AISLE';
export interface Seat{id:string;label:string;available:boolean;}
export interface Element{type:ElementType;seat?:Seat}
export interface Row{row:number;elements:Element[]}
export interface Section{title:string;rows:Row[]}
export interface Deck{id:string;title:string;sections:Section[]}
export interface SeatMap{decks:Deck[]}
