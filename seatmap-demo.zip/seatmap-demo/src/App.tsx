import SeatMap from './components/SeatMap';
import {seatMap} from './data/seatMapMock';
export default function App(){return <SeatMap data={seatMap}/>;}
