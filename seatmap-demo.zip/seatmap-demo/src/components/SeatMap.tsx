import React,{useState} from 'react';
import {SeatMap as Model} from '../models/seatMap';
export default function SeatMap({data}:{data:Model}){
const [selected,setSelected]=useState<string[]>([]);
const toggle=(id:string)=>setSelected(p=>p.includes(id)?p.filter(x=>x!==id):[...p,id]);
return <><h3>Selected: {selected.join(', ')||'None'}</h3>{data.decks.map(d=><div key={d.id}><h2>{d.title}</h2>{d.sections.map(s=><div key={s.title}><h3>{s.title}</h3>{s.rows.map(r=><div key={r.row} style={{display:'flex',gap:6,margin:'8px 0',alignItems:'center'}}><div style={{width:30}}>{r.row}</div>{r.elements.map((e,i)=>e.type==='AISLE'?<div key={i} style={{width:24}}/>:<button key={e.seat!.id} disabled={!e.seat!.available} onClick={()=>toggle(e.seat!.id)} style={{width:44,height:44,background:!e.seat!.available?'#bbb':selected.includes(e.seat!.id)?'#4caf50':'#1976d2',color:'#fff',border:'none',borderRadius:4}}>{e.seat!.label}</button>)}</div>)}</div>)}</div>)}</>;
}
